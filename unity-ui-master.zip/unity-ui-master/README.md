# Unity UI

An Atom theme for a more native experience on OS X

![unity](https://cloud.githubusercontent.com/assets/1680/6204067/d17b682c-b50a-11e4-8aa7-77f407583779.png)

## Install

From the command line:

```bash
$ apm install unity-ui
```

Alternatively, open Atom Preferences, select Themes > Search for `unity`,
then Install.

Activate the theme by selecting the Themes section of Preferences.
